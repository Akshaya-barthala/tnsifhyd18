package com.day1;

public class Bprivate {
	private void display()
	{
		System.out.println("TNS Sessions");
	}
}

