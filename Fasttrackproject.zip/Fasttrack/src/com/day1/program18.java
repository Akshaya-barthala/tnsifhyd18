package com.day1;

import java.util.Scanner;

public class program18 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number:");
		int number = scanner.nextInt();
		System.out.println("Enter a range:");
		int range = scanner.nextInt();
System.out.print("Multiplicaton Table for" + number + ":");
		for(int i= 1;i< range;i++) {
			System.out.println(number+ "*" +i+ "=" +(number*i));
		}
scanner.close();
	}
}
		