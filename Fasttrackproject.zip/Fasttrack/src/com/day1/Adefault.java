package com.day1;

public class Adefault {
	void display() {
		System.out.println("hello world");
	}

}
