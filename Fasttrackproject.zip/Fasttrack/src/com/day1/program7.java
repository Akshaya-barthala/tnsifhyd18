package com.day1;

import java.util.Scanner;

public class program7 {
	public static void main(String[] args) {
		int num1,num2,num3;
		System.out.print("Enter three integres");
		Scanner in = new Scanner(System.in);
		num1 = in.nextInt();
        num2 = in.nextInt();
		num3 = in.nextInt();
		if(num1 > num2 && num1 > num3)
			System.out.println("The largest number is"+num1);
		if(num2 > num1 && num2 > num3)
			System.out.println("The largest number is"+num2);
		if(num3 > num1 && num3 > num2)
			System.out.println("The largest number is"+num3);
	}

}
