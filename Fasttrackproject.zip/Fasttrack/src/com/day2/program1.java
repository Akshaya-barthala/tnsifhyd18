package com.day2;

import java.util.Scanner;

public class program1 {
	public static void main(String[] args) {
		Scanner input= new Scanner(System.in);
		System.out.println("enter your name:");
		String name = input.nextLine();
		System.out.println("my name is" +name);
		input.close();
	}

}
