package com.day2;

import java.util.Scanner;

public class project4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input= new Scanner(System.in);
		System.out.println("enter your name:");
		String value = input.next();
		System.out.println("using next():" +value);
		input.close();


	}

}
