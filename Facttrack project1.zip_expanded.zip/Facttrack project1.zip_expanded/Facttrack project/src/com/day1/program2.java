package com.day1;

public class program2 {
 public static void main(String[] args) {
	 int n = 30;
	 if(n%2==0)
	System.out.print(n+"is even");
	 else
	System.out.print(n+"is odd");
}
}
