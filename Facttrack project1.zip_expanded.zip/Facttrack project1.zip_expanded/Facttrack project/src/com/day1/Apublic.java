package com.day1;

public class Apublic {
	private void display()
	{
		System.out.println("TNS Sessions");
	}
}


