package com.day1;

public class program1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.out.print("Hello world");
	}
}
