package com.day1;


public class Bpublic {
	public static void main(String[] args) {
		Bpublic obj = new Bpublic();
		obj.display();
		
	}
	}


