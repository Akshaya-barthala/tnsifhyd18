package com.day1;

public class Bdefault {
	public static void main(String args[]) {
		Adefault obj= new Adefault();
		obj.display();
	}

}
