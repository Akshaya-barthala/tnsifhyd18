package com.day2;

import java.util.Scanner;

public class program3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input= new Scanner(System.in);
		System.out.println("enter a doublevalue:");
		double value = input.nextDouble();
		System.out.println("uing nextDouble():"+value);
		input.close();


	}

}
