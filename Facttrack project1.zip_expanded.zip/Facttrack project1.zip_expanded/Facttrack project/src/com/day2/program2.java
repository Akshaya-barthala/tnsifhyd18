package com.day2;

import java.util.Scanner;

public class program2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input= new Scanner(System.in);
		System.out.println("enter an integer:");
		int data1 = input.nextInt();
		System.out.println("using nextInt():" +data1);
		input.close();

	}

}
