package com.day2;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Scanner;

public class program6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input= new Scanner(System.in);
		System.out.println("enter a big integer:");
		BigInteger value1 = input.nextBigInteger();
		System.out.println("using nextBigIntegervalue():" +value1);
		System.out.print("enter a big decimal:");
		BigDecimal value2 = input.nextBigDecimal();
		
		System.out.println("using next Bigdecimal():" +value2);

		input.close();


	}

}
