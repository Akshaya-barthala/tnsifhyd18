package com.day2;

import java.util.Scanner;

public class project5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input= new Scanner(System.in);
		System.out.println("enter your name:");
		String value = input.nextLine();
		System.out.println("using nextLine():" +value);
		input.close();


	}

}
