package com.day2;

public class project8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 1;  
        int y = 12 - x;  
        System.out.println(y);  
        
        System.out.println("--------------------------------------------");
        
        int a = 1;  
        int b = 12 * 2;  
        System.out.println(b);  
        
        System.out.println("--------------------------------------------");
        
        
        int v = 1+2;  
        String s = "Hello" + " world";  
        System.out.println(v);  
        System.out.println(s);
        
        System.out.println("--------------------------------------------");
        
        int q = 1;  
        int r = 12 / 2;  
        System.out.println(r);  
        
        System.out.println("--------------------------------------------");
        
        int mod = 13 % 2;

		System.out.println(mod);
		
		System.out.println("--------------------------------------------");
		
		int p = 10;
        System.out.println(p++);
        
        System.out.println("--------------------------------------------");
        
        int k = 10;
        System.out.println(k++);
        
        System.out.println("--------------------------------------------");
        
        int g = 10;
        System.out.println(g--);
        
        System.out.println("--------------------------------------------");
        
        int n = 10;
		System.out.println(--n);
		
		System.out.println("--------------------------------------------");
		
		boolean f;
		f = (5<4)?true:false;
		System.out.println(f);


	}

}


